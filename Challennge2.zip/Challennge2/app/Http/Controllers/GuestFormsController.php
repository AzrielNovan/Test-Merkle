<?php

namespace App\Http\Controllers;

use App\Models\guest_forms;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class GuestFormsController extends Controller
{

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator=Validator::make($request->all(),
            [
                'name' => 'required',
                'address' => 'required',
                'phone' => 'required',
                'note' => 'required',
            ]
        );

        if($validator->fails()) {
            return Response()->json($validator->errors());
        }

        $simpan = guest_forms::create([
            'name' => $request->name,
            'address' => $request->address,
            'phone' => $request->phone,
            'note' => $request->note,
        ]);

        $data = guest_forms::where('name', '=', $request->name)-> get();

        if($simpan)
        {
            return Response()->json([
                'status' => 1,
                'message' => 'Succes create new data!',
                'data' => $data
            ]);
        }
        else
        {
            return Response()->json([
                'status' => 0,
                'message' => 'Failed create data!'
            ]);
        }
    }

    public function show()
    {
        $data = guest_forms::join('name', 'note')->get();
        return Response()->json($data);
    }

    public function showdetail()
    {
        $data = guest_forms::join('name', 'address', 'phone', 'note')->get();
        return Response()->json($data);
    }

}
