<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class guest_forms extends Model
{
    use HasFactory;

    protected $table = 'guest_forms';
    public $timestamp = false;

    protected $fillable = ['name', 'address', 'phone', 'note'];
}
